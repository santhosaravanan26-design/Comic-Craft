"""Builds a whole comic: script -> panel images -> finished page."""
import json
import random
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from .image_generator import generate_image
from .prompt_generator import generate_script

OUTPUT_DIR = Path(__file__).resolve().parent.parent / "generated_comics"

INK = "#14213D"
PAPER = "#FBFBF7"
CAPTION_BG = "#FFD23F"
CELL = 512
GAP = 24
MARGIN = 36
TITLE_H = 120
BORDER = 6

FONT_CANDIDATES = [
    "DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "arialbd.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/Library/Fonts/Arial Bold.ttf",
]


def _font(size: int):
    for name in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def _wrap(draw, text, font, max_width):
    lines, current = [], ""
    for word in text.split():
        trial = f"{current} {word}".strip()
        if draw.textlength(trial, font=font) <= max_width or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _draw_caption(page, box, text):
    """Draw a yellow caption box along the bottom of a panel."""
    x0, y0, x1, y1 = box
    draw = ImageDraw.Draw(page)
    font = _font(22)
    pad = 12
    lines = _wrap(draw, text, font, (x1 - x0) - 2 * (pad + 10) - 8)
    line_h = 28
    height = len(lines) * line_h + 2 * pad
    bx0, bx1 = x0 + 10, x1 - 10
    by1 = y1 - 10
    by0 = by1 - height
    draw.rectangle((bx0, by0, bx1, by1), fill=CAPTION_BG, outline=INK, width=3)
    for i, line in enumerate(lines):
        draw.text((bx0 + pad, by0 + pad + i * line_h), line, font=font, fill=INK)


def _layout(count):
    cols = 1 if count == 1 else 3 if count == 6 else 2
    cells = []
    for i in range(count):
        row, col = divmod(i, cols)
        is_last = i == count - 1
        span = cols if (is_last and count % cols == 1 and cols > 1) else 1
        cells.append((row, col, span))
    rows = max(c[0] for c in cells) + 1
    return cols, rows, cells


def assemble_page(title, panel_images, captions):
    count = len(panel_images)
    cols, rows, cells = _layout(count)
    width = 2 * MARGIN + cols * CELL + (cols - 1) * GAP
    height = 2 * MARGIN + TITLE_H + rows * CELL + (rows - 1) * GAP
    page = Image.new("RGB", (width, height), PAPER)
    draw = ImageDraw.Draw(page)

    draw.rectangle((MARGIN, MARGIN, width - MARGIN, MARGIN + TITLE_H - 24), fill=CAPTION_BG, outline=INK, width=BORDER)
    size = 56
    title_font = _font(size)
    while draw.textlength(title, font=title_font) > width - 2 * MARGIN - 60 and size > 24:
        size -= 4
        title_font = _font(size)
    draw.text((MARGIN + 30, MARGIN + 12), title, font=title_font, fill=INK)

    top = MARGIN + TITLE_H
    for img, caption, (row, col, span) in zip(panel_images, captions, cells):
        w = span * CELL + (span - 1) * GAP
        x0 = MARGIN + col * (CELL + GAP)
        y0 = top + row * (CELL + GAP)
        fitted = ImageOps.fit(img, (w, CELL), Image.LANCZOS)
        draw.rectangle((x0 + 8, y0 + 8, x0 + w + 8, y0 + CELL + 8), fill=INK)
        page.paste(fitted, (x0, y0))
        draw.rectangle((x0, y0, x0 + w, y0 + CELL), outline=INK, width=BORDER)
        _draw_caption(page, (x0, y0, x0 + w, y0 + CELL), caption)
    return page


def create_comic(story: str, style: str, panels: int) -> dict:
    """Generate a full comic and save it to generated_comics/<id>/."""
    comic_id = uuid.uuid4().hex[:12]
    folder = OUTPUT_DIR / comic_id
    folder.mkdir(parents=True, exist_ok=True)

    script = generate_script(story, style, panels)
    seed = random.randint(1, 999999)  # same seed keeps the look consistent

    def work(item):
        index, panel = item
        return generate_image(panel["image_prompt"], style, index, seed)

    with ThreadPoolExecutor(max_workers=2) as pool:
        images = list(pool.map(work, enumerate(script["panels"])))

    captions = [p["caption"] for p in script["panels"]]
    for i, img in enumerate(images, start=1):
        img.save(folder / f"panel_{i}.png")
    page = assemble_page(script["title"], images, captions)
    page.save(folder / "comic.png")

    meta = {
        "id": comic_id,
        "title": script["title"],
        "style": style,
        "story": story,
        "panels": [
            {"caption": c, "image": f"/comics/{comic_id}/panel_{i}.png"}
            for i, c in enumerate(captions, start=1)
        ],
        "comic_url": f"/comics/{comic_id}/comic.png",
    }
    (folder / "comic.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def list_comics(limit: int = 12) -> list:
    items = []
    for path in OUTPUT_DIR.glob("*/comic.json"):
        try:
            items.append((path.stat().st_mtime, json.loads(path.read_text(encoding="utf-8"))))
        except (OSError, ValueError):
            continue
    items.sort(key=lambda t: t[0], reverse=True)
    return [m for _, m in items[:limit]]
