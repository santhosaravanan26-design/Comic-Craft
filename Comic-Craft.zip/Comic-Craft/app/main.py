"""Flask application factory and routes."""
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

from .comic_generator import OUTPUT_DIR, create_comic, list_comics  # noqa: E402
from .prompt_generator import STYLES  # noqa: E402

MAX_STORY_CHARS = 1500

STYLE_LABELS = {
    "superhero": "Superhero",
    "manga": "Manga",
    "pulp": "Retro pulp",
    "cartoon": "Cartoon",
    "noir": "Noir",
    "storybook": "Storybook",
}


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )
    OUTPUT_DIR.mkdir(exist_ok=True)

    @app.get("/")
    def index():
        styles = [(key, STYLE_LABELS.get(key, key.title())) for key in STYLES]
        return render_template("index.html", styles=styles)

    @app.post("/api/generate")
    def generate():
        data = request.get_json(silent=True) or {}
        story = str(data.get("story", "")).strip()
        style = str(data.get("style", "cartoon"))
        try:
            panels = int(data.get("panels", 4))
        except (TypeError, ValueError):
            panels = 4

        if len(story) < 10:
            return jsonify(error="Write at least a sentence or two so there's something to draw."), 400
        if len(story) > MAX_STORY_CHARS:
            return jsonify(error=f"Keep the story under {MAX_STORY_CHARS} characters."), 400
        if style not in STYLES:
            return jsonify(error="Pick one of the listed art styles."), 400
        panels = max(2, min(6, panels))

        try:
            return jsonify(create_comic(story, style, panels))
        except Exception as exc:
            app.logger.exception("Comic generation failed")
            return jsonify(error=f"Something went wrong while drawing: {exc}"), 500

    @app.get("/api/comics")
    def comics():
        return jsonify(list_comics())

    @app.get("/comics/<comic_id>/<path:filename>")
    def comic_file(comic_id, filename):
        return send_from_directory(OUTPUT_DIR / comic_id, filename)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG") == "1")
