"""Creates one panel image from a text prompt.

Providers (set IMAGE_PROVIDER in .env): pollinations, openai, placeholder.
If a provider fails, a placeholder panel is returned so the comic still builds.
"""
import base64
import io
import os
import time
from urllib.parse import quote

import requests
from PIL import Image, ImageDraw, ImageFont

from .prompt_generator import STYLES

PANEL_SIZE = 768


def _pollinations(prompt: str, seed: int) -> Image.Image:
    url = f"https://image.pollinations.ai/prompt/{quote(prompt)}"
    params = {"width": PANEL_SIZE, "height": PANEL_SIZE, "seed": seed, "nologo": "true"}
    last_error = None
    for attempt in range(3):
        try:
            response = requests.get(url, params=params, timeout=90)
            response.raise_for_status()
            return Image.open(io.BytesIO(response.content)).convert("RGB")
        except Exception as exc:
            last_error = exc
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"Pollinations failed: {last_error}")


def _openai(prompt: str) -> Image.Image:
    response = requests.post(
        "https://api.openai.com/v1/images/generations",
        headers={"Authorization": f"Bearer {os.getenv('OPENAI_API_KEY', '')}"},
        json={
            "model": os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1"),
            "prompt": prompt,
            "size": "1024x1024",
            "n": 1,
        },
        timeout=120,
    )
    response.raise_for_status()
    item = response.json()["data"][0]
    if item.get("b64_json"):
        raw = base64.b64decode(item["b64_json"])
    else:
        raw = requests.get(item["url"], timeout=60).content
    return Image.open(io.BytesIO(raw)).convert("RGB")


def _placeholder(index: int) -> Image.Image:
    palette = ["#FFD23F", "#3BCEAC", "#EE4266", "#7EA8F8", "#F49D37", "#B388EB"]
    img = Image.new("RGB", (PANEL_SIZE, PANEL_SIZE), palette[index % len(palette)])
    draw = ImageDraw.Draw(img)
    for y in range(0, PANEL_SIZE, 32):
        for x in range(0, PANEL_SIZE, 32):
            r = 3 + int(9 * (y / PANEL_SIZE))
            ox = 16 if (y // 32) % 2 else 0
            draw.ellipse((x + ox - r, y - r, x + ox + r, y + r), fill=(255, 255, 255))
    try:
        font = ImageFont.load_default(size=44)
    except TypeError:
        font = ImageFont.load_default()
    label = f"Panel {index + 1}"
    w = draw.textlength(label, font=font)
    draw.rectangle(((PANEL_SIZE - w) / 2 - 20, 300, (PANEL_SIZE + w) / 2 + 20, 380), fill="#14213D")
    draw.text(((PANEL_SIZE - w) / 2, 316), label, font=font, fill="white")
    return img


def generate_image(prompt: str, style: str, index: int, seed: int) -> Image.Image:
    provider = os.getenv("IMAGE_PROVIDER", "pollinations").strip().lower()
    full_prompt = f"{prompt}. Style: {STYLES.get(style, STYLES['cartoon'])}. No text, no speech bubbles, no lettering."
    try:
        if provider == "openai":
            return _openai(full_prompt)
        if provider == "placeholder":
            return _placeholder(index)
        return _pollinations(full_prompt, seed)
    except Exception as exc:
        print(f"[image_generator] panel {index + 1} failed: {exc}")
        return _placeholder(index)
