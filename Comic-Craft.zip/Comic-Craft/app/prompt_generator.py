"""Turns a short story into a panel-by-panel comic script.

If ANTHROPIC_API_KEY is set, Claude writes the script. Otherwise a simple
sentence splitter is used so the app still works without any keys.
"""
import json
import os
import re

import requests

STYLES = {
    "superhero": "classic American superhero comic, bold ink outlines, dynamic poses, vivid colors",
    "manga": "black and white manga, screentone shading, expressive faces, dramatic speed lines",
    "pulp": "retro 1950s pulp comic, halftone dots, limited color palette, aged print look",
    "cartoon": "friendly cartoon style, rounded shapes, bright flat colors, playful and clean",
    "noir": "film noir graphic novel, high contrast black and white, deep shadows, moody lighting",
    "storybook": "watercolor storybook illustration, soft edges, warm gentle colors",
}

SYSTEM_PROMPT = (
    "You are a comic book writer. Turn the user's story into a comic script. "
    "Reply with JSON only, no markdown fences, in exactly this shape: "
    '{"title": "short title", "panels": [{"caption": "one short sentence, max 18 words", '
    '"image_prompt": "a detailed visual description of the scene"}]}. '
    "Rules: produce exactly the requested number of panels; each caption reads well on its own; "
    "describe every main character's look (age, hair, clothes, colors) inside EVERY image_prompt "
    "so they stay consistent; never ask for text, speech bubbles or lettering inside the image."
)


def _fallback_script(story: str, panels: int) -> dict:
    """Split the story into roughly equal chunks when no LLM is available."""
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", story.strip()) if s.strip()]
    if not sentences:
        sentences = [story.strip()]
    chunks = [[] for _ in range(panels)]
    for i, sentence in enumerate(sentences):
        chunks[min(i * panels // len(sentences), panels - 1)].append(sentence)
    result = []
    for i, chunk in enumerate(chunks):
        text = " ".join(chunk) or sentences[min(i, len(sentences) - 1)]
        text = text if len(text) <= 140 else text[:137].rstrip() + "..."
        result.append({"caption": text, "image_prompt": text})
    first = sentences[0].rstrip(" .,!?")
    if len(first) > 40:
        first = first[:40].rsplit(" ", 1)[0]
    title = first or "My Comic"
    return {"title": title, "panels": result}


def _parse_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("No JSON object found in model reply")
    return json.loads(text[start : end + 1])


def _claude_script(story: str, style: str, panels: int) -> dict:
    api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
            "max_tokens": 1500,
            "system": SYSTEM_PROMPT,
            "messages": [
                {
                    "role": "user",
                    "content": f"Number of panels: {panels}\nArt style: {STYLES[style]}\n\nStory:\n{story}",
                }
            ],
        },
        timeout=60,
    )
    response.raise_for_status()
    blocks = response.json().get("content", [])
    text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
    data = _parse_json(text)
    items = data.get("panels", [])
    if len(items) < panels:
        raise ValueError("Model returned too few panels")
    cleaned = []
    for item in items[:panels]:
        caption = str(item.get("caption", "")).strip()
        prompt = str(item.get("image_prompt", caption)).strip() or caption
        cleaned.append({"caption": caption, "image_prompt": prompt})
    return {"title": str(data.get("title", "My Comic")).strip()[:60] or "My Comic", "panels": cleaned}


def generate_script(story: str, style: str, panels: int) -> dict:
    """Return {"title": str, "panels": [{"caption", "image_prompt"}, ...]}."""
    if style not in STYLES:
        style = "cartoon"
    if os.getenv("ANTHROPIC_API_KEY", "").strip():
        try:
            return _claude_script(story, style, panels)
        except Exception as exc:  # fall back rather than failing the whole request
            print(f"[prompt_generator] Claude failed, using fallback: {exc}")
    return _fallback_script(story, panels)
