# Comic Craft

Type a short story and get a finished comic page. Comic Craft writes a panel-by-panel
script, draws each panel, and lays everything out as one downloadable PNG.

## How it works

1. `prompt_generator.py` turns your story into panel captions and image prompts
   (Claude if you add an API key, otherwise a simple built-in splitter).
2. `image_generator.py` draws each panel (Pollinations by default, OpenAI optional).
3. `comic_generator.py` assembles the panels, borders and captions into one page.
4. `main.py` serves the web app and the JSON API.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then edit .env (optional)
python run.py
```

Open http://127.0.0.1:5000

## Configuration (`.env`)

| Variable | What it does |
|---|---|
| `ANTHROPIC_API_KEY` | Enables Claude-written scripts. Leave empty to use the built-in splitter. |
| `ANTHROPIC_MODEL` | Model used for scripting (default `claude-sonnet-4-6`). |
| `IMAGE_PROVIDER` | `pollinations` (free, no key), `openai`, or `placeholder` (offline demo). |
| `OPENAI_API_KEY` | Required when `IMAGE_PROVIDER=openai`. |
| `PORT`, `HOST`, `FLASK_DEBUG` | Server settings. |

If image generation fails for a panel, a placeholder panel is used so the comic still builds.

## API

`POST /api/generate` with JSON `{"story": "...", "style": "cartoon", "panels": 4}`
returns the title, panel captions and the URL of the finished page.
`GET /api/comics` lists recent comics.

Finished comics are saved in `generated_comics/`.

## Project layout

```
app/        Flask app, script and image generation
static/     CSS, JavaScript, logo
templates/  index.html
generated_comics/  Output (git-ignored)
```
