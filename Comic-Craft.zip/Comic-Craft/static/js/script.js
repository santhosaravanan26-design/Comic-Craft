(() => {
  const form = document.getElementById("comic-form");
  const story = document.getElementById("story");
  const count = document.getElementById("count");
  const submit = document.getElementById("submit");
  const errorBox = document.getElementById("error");
  const empty = document.getElementById("empty");
  const loading = document.getElementById("loading");
  const result = document.getElementById("result");
  const resultTitle = document.getElementById("result-title");
  const resultImage = document.getElementById("result-image");
  const download = document.getElementById("download");
  const scriptList = document.getElementById("script");
  const recent = document.getElementById("recent");
  const recentList = document.getElementById("recent-list");

  story.addEventListener("input", () => {
    count.textContent = story.value.length;
  });

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = !message;
  }

  function showLoading(panels) {
    empty.hidden = true;
    result.hidden = true;
    loading.hidden = false;
    loading.replaceChildren();
    for (let i = 0; i < panels; i++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.style.animationDelay = `${i * 0.18}s`;
      loading.appendChild(cell);
    }
    const status = document.createElement("p");
    status.className = "status";
    status.textContent = "Drawing your panels. This usually takes under a minute.";
    loading.appendChild(status);
  }

  function showComic(comic) {
    loading.hidden = true;
    empty.hidden = true;
    result.hidden = false;
    resultTitle.textContent = comic.title;
    resultImage.src = comic.comic_url;
    resultImage.alt = `Comic page titled ${comic.title}`;
    download.href = comic.comic_url;
    download.setAttribute("download", `${comic.title.replace(/[^\w]+/g, "-").toLowerCase() || "comic"}.png`);
    scriptList.replaceChildren();
    comic.panels.forEach((panel) => {
      const li = document.createElement("li");
      li.textContent = panel.caption;
      scriptList.appendChild(li);
    });
    result.scrollIntoView({ block: "start" });
  }

  async function loadRecent() {
    try {
      const response = await fetch("/api/comics");
      const comics = await response.json();
      recentList.replaceChildren();
      comics.forEach((comic) => {
        const li = document.createElement("li");
        const button = document.createElement("button");
        button.type = "button";
        const img = document.createElement("img");
        img.src = comic.comic_url;
        img.alt = "";
        img.loading = "lazy";
        const label = document.createElement("span");
        label.textContent = comic.title;
        button.append(img, label);
        button.addEventListener("click", () => showComic(comic));
        li.appendChild(button);
        recentList.appendChild(li);
      });
      recent.hidden = comics.length === 0;
    } catch (err) {
      recent.hidden = true;
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    showError("");
    const data = new FormData(form);
    const payload = {
      story: story.value.trim(),
      style: data.get("style"),
      panels: Number(data.get("panels")),
    };
    if (payload.story.length < 10) {
      showError("Write at least a sentence or two so there's something to draw.");
      story.focus();
      return;
    }

    submit.disabled = true;
    submit.textContent = "Drawing...";
    showLoading(payload.panels);

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "The comic could not be drawn.");
      showComic(body);
      loadRecent();
    } catch (err) {
      loading.hidden = true;
      empty.hidden = false;
      showError(err.message);
    } finally {
      submit.disabled = false;
      submit.textContent = "Draw my comic";
    }
  });

  loadRecent();
})();
